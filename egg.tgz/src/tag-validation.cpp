// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("tag validation\n", stdout);
  return lionss_run_workload("tag-validation");
}
