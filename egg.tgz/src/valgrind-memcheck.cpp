// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("valgrind memcheck\n", stdout);
  return lionss_run_workload("valgrind-memcheck");
}
