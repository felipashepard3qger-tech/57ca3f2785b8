// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("leap second tests"); }
int main(){
  announce();
  return lionss_run_workload("leap-second-tests");
}
