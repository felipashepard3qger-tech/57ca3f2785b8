// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("fetchcontent check"); }
int main(){
  announce();
  return lionss_run_workload("fetchcontent-check");
}
